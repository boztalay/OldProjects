/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0xef153c89 */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Ben/Desktop/FPGA/Projects/Current Projects/Systems/Sys_SecondTimer/Comp_Counter4bit.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3620187407;

unsigned char ieee_p_2592010699_sub_1258338084_2592010699(char *, char *, unsigned int , unsigned int );
char *ieee_p_3620187407_sub_4215186851_3620187407(char *, char *, char *, char *, char *, char *);
unsigned char ieee_std_logic_unsigned_equal_stdv_stdv(char *, char *, char *, char *, char *);


static void work_a_0242572871_3212880686_p_0(char *t0)
{
    char t11[16];
    char t20[16];
    char *t1;
    unsigned char t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t12;
    char *t13;
    int t14;
    unsigned int t15;
    unsigned char t16;
    char *t17;
    char *t18;
    char *t19;
    unsigned int t21;

LAB0:    xsi_set_current_line(46, ng0);
    t1 = (t0 + 528U);
    t2 = ieee_p_2592010699_sub_1258338084_2592010699(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    xsi_set_current_line(53, ng0);
    t1 = (t0 + 888U);
    t4 = *((char **)t1);
    t1 = (t0 + 1620);
    t5 = (t1 + 32U);
    t8 = *((char **)t5);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t4, 4U);
    xsi_driver_first_trans_fast_port(t1);
    t1 = (t0 + 1576);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(47, ng0);
    t4 = (t0 + 636U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    if (t7 == 1)
        goto LAB8;

LAB9:    t4 = (t0 + 888U);
    t8 = *((char **)t4);
    t4 = (t0 + 2676U);
    t9 = (t0 + 2704);
    t12 = (t11 + 0U);
    t13 = (t12 + 0U);
    *((int *)t13) = 0;
    t13 = (t12 + 4U);
    *((int *)t13) = 3;
    t13 = (t12 + 8U);
    *((int *)t13) = 1;
    t14 = (3 - 0);
    t15 = (t14 * 1);
    t15 = (t15 + 1);
    t13 = (t12 + 12U);
    *((unsigned int *)t13) = t15;
    t16 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t8, t4, t9, t11);
    t3 = t16;

LAB10:    if (t3 != 0)
        goto LAB5;

LAB7:    xsi_set_current_line(50, ng0);
    t1 = (t0 + 888U);
    t4 = *((char **)t1);
    t1 = (t0 + 2676U);
    t5 = (t0 + 2712);
    t9 = (t20 + 0U);
    t10 = (t9 + 0U);
    *((int *)t10) = 0;
    t10 = (t9 + 4U);
    *((int *)t10) = 3;
    t10 = (t9 + 8U);
    *((int *)t10) = 1;
    t14 = (3 - 0);
    t15 = (t14 * 1);
    t15 = (t15 + 1);
    t10 = (t9 + 12U);
    *((unsigned int *)t10) = t15;
    t10 = ieee_p_3620187407_sub_4215186851_3620187407(IEEE_P_3620187407, t11, t4, t1, t5, t20);
    t12 = (t0 + 888U);
    t13 = *((char **)t12);
    t12 = (t13 + 0);
    t17 = (t11 + 12U);
    t15 = *((unsigned int *)t17);
    t21 = (1U * t15);
    memcpy(t12, t10, t21);

LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(48, ng0);
    t13 = (t0 + 2708);
    t18 = (t0 + 888U);
    t19 = *((char **)t18);
    t18 = (t19 + 0);
    memcpy(t18, t13, 4U);
    goto LAB6;

LAB8:    t3 = (unsigned char)1;
    goto LAB10;

}


extern void work_a_0242572871_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0242572871_3212880686_p_0};
	xsi_register_didat("work_a_0242572871_3212880686", "isim/_tmp/work/a_0242572871_3212880686.didat");
	xsi_register_executes(pe);
}
