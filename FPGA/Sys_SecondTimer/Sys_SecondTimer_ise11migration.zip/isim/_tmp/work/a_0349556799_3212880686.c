/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0xef153c89 */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Ben/Desktop/FPGA/Projects/Current Projects/Systems/Sys_SecondTimer/Comp_DecadeCnt4bit.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1258338084_2592010699(char *, char *, unsigned int , unsigned int );


static void work_a_0349556799_3212880686_p_0(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    int t11;
    int t12;
    unsigned char t13;
    char *t14;
    char *t15;

LAB0:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 528U);
    t2 = ieee_p_2592010699_sub_1258338084_2592010699(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    xsi_set_current_line(67, ng0);
    t1 = (t0 + 888U);
    t3 = *((char **)t1);
    t1 = (t0 + 1684);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t14 = (t5 + 40U);
    t15 = *((char **)t14);
    memcpy(t15, t3, 4U);
    xsi_driver_first_trans_fast_port(t1);
    t1 = (t0 + 1640);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(49, ng0);
    t3 = (t0 + 888U);
    t4 = *((char **)t3);
    t3 = (t0 + 952U);
    t5 = *((char **)t3);
    t6 = *((int *)t5);
    t7 = (t6 - 3);
    t8 = (t7 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, t6);
    t9 = (1U * t8);
    t10 = (0 + t9);
    t3 = (t4 + t10);
    *((unsigned char *)t3) = (unsigned char)3;
    xsi_set_current_line(50, ng0);
    t1 = (t0 + 952U);
    t3 = *((char **)t1);
    t6 = *((int *)t3);
    t2 = (t6 != 0);
    if (t2 != 0)
        goto LAB5;

LAB7:    xsi_set_current_line(53, ng0);
    t1 = (t0 + 888U);
    t3 = *((char **)t1);
    t6 = (3 - 3);
    t8 = (t6 * -1);
    t9 = (1U * t8);
    t10 = (0 + t9);
    t1 = (t3 + t10);
    *((unsigned char *)t1) = (unsigned char)2;

LAB6:    xsi_set_current_line(56, ng0);
    t1 = (t0 + 952U);
    t3 = *((char **)t1);
    t6 = *((int *)t3);
    t2 = (t6 < 3);
    if (t2 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 952U);
    t3 = *((char **)t1);
    t1 = (t3 + 0);
    *((int *)t1) = 0;

LAB9:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 636U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t13 = (t2 == (unsigned char)3);
    if (t13 != 0)
        goto LAB11;

LAB13:
LAB12:    goto LAB3;

LAB5:    xsi_set_current_line(51, ng0);
    t1 = (t0 + 888U);
    t4 = *((char **)t1);
    t1 = (t0 + 952U);
    t5 = *((char **)t1);
    t7 = *((int *)t5);
    t11 = (t7 - 1);
    t12 = (t11 - 3);
    t8 = (t12 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, t11);
    t9 = (1U * t8);
    t10 = (0 + t9);
    t1 = (t4 + t10);
    *((unsigned char *)t1) = (unsigned char)2;
    goto LAB6;

LAB8:    xsi_set_current_line(57, ng0);
    t1 = (t0 + 952U);
    t4 = *((char **)t1);
    t7 = *((int *)t4);
    t11 = (t7 + 1);
    t1 = (t0 + 952U);
    t5 = *((char **)t1);
    t1 = (t5 + 0);
    *((int *)t1) = t11;
    goto LAB9;

LAB11:    xsi_set_current_line(63, ng0);
    t1 = (t0 + 888U);
    t4 = *((char **)t1);
    t1 = (t0 + 952U);
    t5 = *((char **)t1);
    t6 = *((int *)t5);
    t7 = (t6 - 1);
    t11 = (t7 - 3);
    t8 = (t11 * -1);
    xsi_vhdl_check_range_of_index(3, 0, -1, t7);
    t9 = (1U * t8);
    t10 = (0 + t9);
    t1 = (t4 + t10);
    *((unsigned char *)t1) = (unsigned char)2;
    xsi_set_current_line(64, ng0);
    t1 = (t0 + 952U);
    t3 = *((char **)t1);
    t1 = (t3 + 0);
    *((int *)t1) = 0;
    goto LAB12;

}


extern void work_a_0349556799_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0349556799_3212880686_p_0};
	xsi_register_didat("work_a_0349556799_3212880686", "isim/_tmp/work/a_0349556799_3212880686.didat");
	xsi_register_executes(pe);
}
